cmsAddUser -p lQZk0a5GaogU 'Lê Nguyễn Hữu ' 'An' u0501
cmsAddUser -p hEoQGsC7hx1i 'Nguyễn Đức ' 'Anh' u0502
cmsAddUser -p ZD7VKTOeKNUI 'Nguyễn Hải ' 'Anh' u0503
cmsAddUser -p LRDY6BHSHCCF 'Trần Tuấn ' 'Anh' u0504
cmsAddUser -p Cfng760AFo6F 'Hoàng Xuân ' 'Bách' u0505
cmsAddUser -p PfOvAs7Lw2HP 'Nguyễn Cảnh ' 'Dương' u0506
cmsAddUser -p EK7bznHroXML 'Nguyễn Anh ' 'Dũng' u0507
cmsAddUser -p o61gXwBLlyUZ 'Nguyễn Hoàng ' 'Gia' u0508
cmsAddUser -p cxnCPmt3A0nk 'Nguyễn Trung ' 'Hải' u0509
cmsAddUser -p 82CHsyLy6Ue0 'Vũ Nam ' 'Hải' u0510
cmsAddUser -p 8LjnBxEpopqh 'Đinh Mạnh ' 'Hùng' u0511
cmsAddUser -p QV7UdgXQ8vlJ 'Đào Huy ' 'Hoàng' u0512
cmsAddUser -p W3UrIUpUKPf7 'Đỗ Gia ' 'Huy' u0513
cmsAddUser -p aVfPzBGfxKz3 'Thiều Nguyễn ' 'Huy' u0514
cmsAddUser -p f91yLxdvqRlD 'Trần Gia ' 'Huy' u0515
cmsAddUser -p Zru2Md1x04kK 'Nguyễn Ngọc Đăng' 'Khoa' u0516
cmsAddUser -p L3FSXfYyuEib 'Nguyễn Tùng ' 'Lâm' u0517
cmsAddUser -p 0xiiQncaDXxS 'Phan Bình Nguyên ' 'Lâm' u0518
cmsAddUser -p EHvoH5BlZzsU 'Đào Quang ' 'Linh' u0519
cmsAddUser -p MSk37NzqwaYs 'Nguyễn Tuấn' 'Linh' u0520
cmsAddUser -p hqIx74j90O4V 'Nguyễn Lê Hoàng ' 'Long' u0521
cmsAddUser -p 2xHuQLHEuqiC 'Phạm Công ' 'Minh' u0522
cmsAddUser -p PG1FJVWj5EI2 'Lê Hoàng' 'Nam' u0523
cmsAddUser -p iPgBWzDFAP0F 'Nguyễn Phú ' 'Nhân' u0524
cmsAddUser -p jZEtsC1MheLC 'Nguyễn Minh ' 'Nhật' u0525
cmsAddUser -p 7iuZYam6QlF6 'Nguyễn Phan Minh ' 'Nhật' u0526
cmsAddUser -p st5rWz3QX95Y 'Lê Thiên ' 'Quân' u0527
cmsAddUser -p 8HdLzVKEpoOp 'Lại Minh' 'Quang' u0528
cmsAddUser -p 7PVHXjlY5QVZ 'Lê Xuân ' 'Sơn' u0529
cmsAddUser -p 6CEtZrf6hQ8w 'Lê Kiến ' 'Thành' u0530
cmsAddUser -p R78H48PruSPr 'Phạm Công ' 'Thành' u0531
cmsAddUser -p OYbKT2Uz8HHZ 'Nguyễn Đức ' 'Thắng' u0532
cmsAddUser -p SNJLqup5cHVm 'Nguyễn Khắc ' 'Thụ' u0533
cmsAddUser -p qwGdhQ8YgxDh 'Bùi Nguyễn Đức ' 'Trọng' u0534
cmsAddUser -p n4QmAMKBsXle 'Phạm Ngọc ' 'Trung' u0535
cmsAddUser -p EpZfukDAvpu0 'Nguyễn Hữu ' 'Tuấn' u0536
cmsAddUser -p uyDmLpYdjwMw 'Nguyễn Trọng Văn ' 'Viết' u0537
cmsAddUser -p FCWGREbLkVJn 'Đặng Nguyên ' 'Vũ' u0538
